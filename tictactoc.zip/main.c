#include <stdio.h>



int main() {
	char t[50][50]; // declaration de la matrice
	int i,j; 
	int cnt=49;
	char b,h;
	int verif=0; 
	//remplir la matrice avec des numero de 1 à 9/
	for (i=0;i<3;i++){
		for (j=0;j<3;j++){
		
		t[i][j]=cnt;
		cnt++;
	}
}


	printf("le jeu commence, let's go! \n \n");
	for (i=0;i<3;i++){
		for (j=0;j<3;j++){
		
		printf("      %c",t[i][j]);
		
	
	}
	printf("\n  ");
	printf("  _____|_____|_____\n");
    printf("         |     |     \n");
}
cnt=0;

b='O';
while(cnt<9 &&verif==0)
{
// verification ce qui le joueur qui joue
      if (b=='X')
         {b='O';}
      else
         {b='X';}

	
	
printf("choisissez un  numero (joueur %c): ",b);
scanf("\n %c",&h);


	if(h=='1' && t[0][0]=='1'){t[0][0]=b;}
	else if (h=='2' && t[0][1]=='2'){t[0][1]=b;}
	else if (h=='3' && t[0][2]=='3'){	t[0][2]=b;}
	else if (h=='4' && t[1][0]=='4'){t[1][0]=b;}
	else if (h=='5' && t[1][1]=='5'){t[1][1]=b;}
	else if (h=='6' && t[1][2]=='6'){t[1][2]=b;}
	else if (h=='7' && t[2][0]=='7'){t[2][0]=b;}
	else if (h=='8' && t[2][1]=='8'){t[2][1]=b;}
	else if (h=='9' && t[2][2]=='9'){t[2][2]=b;}
	else{// si la case choisie est occuppé le meme joueur va rejouer
	     cnt--;
	      if (b=='X')
	   
            	{b='O';}
     	
        	else
		  {b='X';}
	           
     	}
	
		
	system("cls");	
	printf("tic tac toc  \n \n");
	for (i=0;i<3;i++){
		for (j=0;j<3;j++){
		
		printf("      %c",t[i][j]);
		
	
	}
	printf("\n  ");
	printf("  _____|_____|_____\n");
    printf("         |     |     \n");
}
//verification de gagnant
if ((t[0][0]=='X'&& t[0][1]=='X'&& t[0][2]=='X')|| (t[0][0]=='X'&& t[1][0]=='X'&& t[2][0]=='X') ||(t[1][0]=='X'&& t[1][1]=='X'&& t[1][2]=='X') ||(t[2][0]=='X'&& t[2][1]=='X'&& t[2][2]=='X')||(t[0][1]=='X'&& t[1][1]=='X'&& t[2][1]=='X')||(t[0][2]=='X'&& t[1][2]=='X'&& t[2][2]=='X')||(t[0][0]=='X'&& t[1][1]=='X'&& t[2][2]=='X')||(t[0][2]=='X'&& t[1][1]=='X'&& t[2][0]=='X'))
   {
    	verif=1;
		printf("\n bravo joueur X  ! \n");
	}
else if ((t[0][0]=='O'&& t[0][1]=='O'&& t[0][2]=='O')|| (t[0][0]=='O'&& t[1][0]=='O'&& t[2][0]=='O') ||(t[1][0]=='O'&& t[1][1]=='O'&& t[1][2]=='O') ||(t[2][0]=='O'&& t[2][1]=='O'&& t[2][2]=='O')||(t[0][1]=='O'&& t[1][1]=='O'&& t[2][1]=='O')||(t[0][2]=='O'&& t[1][2]=='O'&& t[2][2]=='O')||(t[0][0]=='O'&& t[1][1]=='O'&& t[2][2]=='O')||(t[0][2]=='O'&& t[1][1]=='O'&& t[2][0]=='O')) 
      {
		printf("\n bravo joueur O   ! \n");
		verif=1;
	  }

cnt++;	
}


if (cnt==9 && verif==0){printf("un match nul!");}
	

	
	return 0;
}

